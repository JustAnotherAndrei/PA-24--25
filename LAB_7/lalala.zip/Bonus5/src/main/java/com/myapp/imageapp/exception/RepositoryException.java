package com.myapp.imageapp.exception;

public class RepositoryException extends ImageAppException {
    public RepositoryException(String message) {
        super(message);
    }

    public RepositoryException(String message, Throwable cause) {
        super(message, cause);
    }
}
